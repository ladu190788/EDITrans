export const SET_LOGGED_IN = "SET_LOGGED_IN";
export const SET_LOGGED_IN_USERNAME = "SET_LOGGED_IN_USERNAME";
export const SET_ACTIVE_ROUTE = "SET_ACTIVE_ROUTE";

export const setLoggedIn = (logged_in) => { return { type: SET_LOGGED_IN, logged_in }; };
export const setLoggedInUsername = (loggedInUsername) => { return { type: SET_LOGGED_IN_USERNAME, loggedInUsername }; };
export const setActiveRoute = (route) => { return { type: SET_ACTIVE_ROUTE, route } };
