import React, { Component } from 'react';
import { connect } from 'react-redux';
import { BrowserRouter, Route, Link, Redirect, withRouter } from 'react-router-dom';
import { Container, Segment, Button, Menu, Sidebar, Icon, Image } from 'semantic-ui-react';
import LoginScreen from './screens/LoginScreen';
import DashBoard from './screens/DashBoard.js';
import Revenue from './screens/Revenue';
import Resource from './screens/Resource';
import 'semantic-ui-css/semantic.min.css';
import { store } from './store.js';
import { setLoggedIn, setLoggedInUsername, setActiveRoute } from './actions/auth.js';
import logo from './logo.jpg';

class HeaderBar extends React.Component {
    constructor(props){
        super(props);
        this.state = {
            active: 'home'
        };
        this.logout = this.logout.bind(this);
    }
	
    goToScreen = (screen) => {
        this.setState({ active: screen});
        store.dispatch(setActiveRoute(screen));
        this.props.history.push('/' + screen);
    }

    componentWillReceiveProps(newProps){
        //console.log("RECEIVED NEW PROPS: ", newProps);
    }

    logout(){
        store.dispatch(setLoggedIn(false));
        store.dispatch(setLoggedInUsername(""));
        store.dispatch(setActiveRoute(""));
    }

    render(){
        //console.log(store.getState());
        return(<div>
			<div>
				<div id='myleft'></div> 
				<div id='myright'><Image src={logo} id='logoImg'/></div> 				
				<div id='mycenter' class="Wrapper_orange"><h1><b>EDI TRANS TOOL</b></h1></div> 
			</div>
            <Menu>				 
                
                <Menu.Item name='Eligibility' active={store.getState().auth.active === 'dashboard'} onClick={() => this.goToScreen('dashboard')}/>
                <Menu.Item name='Referral Add' active={store.getState().auth.active === 'revenue'} onClick={() => this.goToScreen('revenue')}/>
				<Menu.Item name='Pre-Cert Add' active={store.getState().auth.active === 'resource'} onClick={() => this.goToScreen('resource')}/>
				<Menu.Item name='Pre-Cert Inquiry' active={store.getState().auth.active === 'resource'} onClick={() => this.goToScreen('resource')}/>
				<Menu.Item name='NOA' active={store.getState().auth.active === 'resource'} onClick={() => this.goToScreen('resource')}/>
				<Menu.Item name='Claims-Professional' active={store.getState().auth.active === 'resource'} onClick={() => this.goToScreen('resource')}/>
				
				
				
				
                <Menu.Menu position='right'>
                    { store.getState().auth.loggedInUsername ?
                        <Menu.Item name='loggedinuser'>
                            Welcome {store.getState().auth.loggedInUsername} !
                        </Menu.Item>
                        :
                        null
                    }
                    { store.getState().auth.loggedIn ? 
                        <Menu.Item name='login'>
                            <Button inverted color='red' onClick={this.logout}>
                                Log Out
                            </Button>
                        </Menu.Item>
                        :
                        <Menu.Item>
                            <Button inverted color='orange' onClick={() => this.goToScreen('login')}>
                                Log In
                            </Button>
                        </Menu.Item>
                    }
                </Menu.Menu>
            </Menu>
		</div>
        );
    }
}

const HeaderBarWithHistory = withRouter((props) => (
    <HeaderBar {...props} />
));

const LoggedInRoute = ({ component: Component, ...rest}) => (
    <Route {...rest}
        render={props => (
            store.getState().auth.loggedIn ? <Component {...props} /> : <Redirect to={{pathname: '/login', state: {from: props.location}}} />
        )}
    />
);


const mapStateToProps = (state, props) => {
    return {
        auth: state.auth
    };
}

class MasterRouter extends Component{
    constructor(props){
        super(props);
        this.state = {
            active: 'home',
        }
    }

    render(){
        return(
            <BrowserRouter>
                <div ref={ref => this.mainContainer = ref}>
                    <HeaderBarWithHistory authState={this.props.auth}/>
                    <LoggedInRoute exact path="/" component={DashBoard} />
                    <LoggedInRoute path="/dashboard" component={DashBoard} />
					<LoggedInRoute path="/resource" component={Resource} />
                    <Route path="/login" component={LoginScreen} />
                    <LoggedInRoute path="/revenue" component={Revenue} mainContainer={this.mainContainer}/>
                </div>
            </BrowserRouter>
        );
    }
}

export default connect(mapStateToProps, null)(MasterRouter);
