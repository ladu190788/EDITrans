import { createStore } from 'redux';
import main from './reducers/main.js';

export let store = createStore(main);
