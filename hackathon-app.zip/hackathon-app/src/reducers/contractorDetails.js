import { SET_CONTRACTOR_DETAILS, SET_CONTRACTOR_DETAILS_APPROVAL } from '../actions/contractorDetails.js';
import _ from 'lodash';

const initialState = {
};

export default function contractorDetails(state = initialState, action){
    switch (action.type){
    case SET_CONTRACTOR_DETAILS:
        return action.contractor;
    case SET_CONTRACTOR_DETAILS_APPROVAL: {
        if (_.isEmpty(action.manager_username)){
            return state;
        }
        let disposition_change_approval = state.disposition_change_approval;
        disposition_change_approval[action.manager_username] = action.approval;
        return {
            ...state,
            disposition_change_approval
        }
    }
    default:
        return state;
    }
}
