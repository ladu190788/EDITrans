import { CLEAR_APPROVALS, SET_APPROVAL, SET_EMPLOYEE, ADD_DISPOSITION_CHANGE, FILTER_EMPLOYEES, RESET_EMPLOYEES, TOGGLE_SELECTED, TOGGLE_ALL_SELECTED, ADD_EMPLOYEE, CLEAR_EMPLOYEES } from '../actions/employees.js';
export const FTE = 'FTE';
export const TER = 'TER';
export const EXT = 'EXT';

/**
 * In order to make this simple, each employee has a 'managers' array
 * this is an _ordered_ array that tells us the reporting hierarchy, with the direct report at the first index
 * This way, we can easily filter out employees based on who logged in, and also determine the structure
 * such that we can do things like 
 * Disallow changes to disposition if a manager higher in the hierarchy has approved it
*/
const initialState = [
    {
        'selected': false,
        'visible': true,
        'network_login': 'bbois',
        'email_address': 'bernard.bois@arris.com',
        "first_name": "Bernard",
        "id": 234,
        "last_name": "Bois",
        "rate": "51de81",
        "currency": "CAD",
        "title": "Demo Expert",
        "direct_report": "Jaspreet Sachdev",
        "image": "https://ui-avatars.com/api/?name=Ber+Bois",
        "approved": false,
        "last_hire_date": '2010-03-30',
        "expected_end_date": '2020-08-30',
        "managers": [
            {
                "username": "jsachdev",
                "first_name": "Jaspreet",
                "last_name": "Sachdev"
            },
            {
                "username": "fhasle",
                "first_name": "Fred",
                "last_name": "Hasle"
            },
            {
                "username": "jraynor",
                "first_name": "Jack",
                "last_name": "Raynor"
            },
            {
                "username": "ctrivedi",
                "first_name": "Chirag",
                "last_name": "Trivedi"
            },
        ],
        "disposition_change_approval": {},
        "disposition_changes": [],
    },
    {
        'selected': false,
        'visible': true,
        'network_login': 'zliau',
        'email_address': 'zhanhong.liau@arris.com',
        "first_name": "Zhan",
        "id": 123,
        "last_name": "Liau",
        "rate": 50,
        "currency": "CAD",
        "title": "SO Results Aggregator",
        "direct_report": "Jaspreet Sachdev",
        "image": "https://ui-avatars.com/api/?name=Zhan+L",
        "approved": false,
        "last_hire_date": '2011-06-30',
        "expected_end_date": '2020-06-30',
        "managers": [
            {
                "username" :"always_wrong",
                "first_name": "Always",
                "last_name": "Wrong"
            },
            {
                "username": "jsachdev",
                "first_name": "Jaspreet",
                "last_name": "Sachdev",
            },
            {
                "username": "fhasle",
                "first_name": "Fred",
                "last_name": "Hasle"
            },
            {
                "username": "jraynor",
                "first_name": "Jack",
                "last_name": "Raynor"
            },
            {
                "username": "ctrivedi",
                "first_name": "Chirag",
                "last_name": "Trivedi"
            },
        ],
        "disposition_change_approval": {
            'jsachdev': {
                "approved": true
            }
        },
        "disposition_changes": [
            {
                'disposition': TER,
                'submitted_by': 'always_wrong',
                'comment': 'This contractor is not worth it',
                'time': '2018-01-21 14:30:00'
            },
            {
                'disposition': EXT,
                'submitted_by': 'jsachdev',
                'comment': 'This contractor is worth it',
                'time': '2018-01-20 10:30:00'
            }
        ]
    },
    {
        'selected': false,
        'visible': true,
        'network_login': 'bpatel',
        'email_address': 'bhavesh.patel@arris.com',
        "first_name": "Bhavesh",
        "id": 567,
        "last_name": "Patel",
        "rate": 50,
        "currency": "CAD",
        "title": "Bhavesh-of-all-trades",
        "direct_report": "Jaspreet Sachdev",
        "image": "https://ui-avatars.com/api/?name=Bha+Pat",
        "approved": false,
        "last_hire_date": '2017-01-30',
        "expected_end_date": '2050-12-30',
        "managers": [
            {
                "username": "jsachdev",
                "first_name": "Jaspreet",
                "last_name": "Sachdev",
            },
            {
                "username": "fhasle",
                "first_name": "Fred",
                "last_name": "Hasle"
            },
            {
                "username": "jraynor",
                "first_name": "Jack",
                "last_name": "Raynor"
            },
            {
                "username": "ctrivedi",
                "first_name": "Chirag",
                "last_name": "Trivedi"
            },
        ],
        "disposition_change_approval": {},
        "disposition_changes": [],
    },
    {
        'selected': false,
        'visible': true,
        'network_login': 'ssiddiqui',
        'email_address': 'ssiddiqui@arris.com',
        "first_name": "Sheraz",
        "id": 22,
        "last_name": "Siddiqui",
        "rate": 50,
        "currency": "CAD",
        "title": "Fullest Stack Developer",
        "direct_report": "Igor Zugic",
        "image": "https://ui-avatars.com/api/?name=Sher+Sid",
        "approved": false,
        "last_hire_date": '2017-08-30',
        "expected_end_date": '2021-06-30',
        "managers": [
            {
                "username": "izugic",
                "first_name": "Igor",
                "last_name": "Zugic",
            },
            {
                "username": "fhasle",
                "first_name": "Fred",
                "last_name": "Hasle"
            },
            {
                "username": "jraynor",
                "first_name": "Jack",
                "last_name": "Raynor"
            },
            {
                "username": "ctrivedi",
                "first_name": "Chirag",
                "last_name": "Trivedi"
            },
        ],
        "disposition_change_approval": {},
        "disposition_changes": [],
    },
    {
        'selected': false,
        'visible': true,
        'network_login': 'ccontractor',
        'email_address': 'cool.contractor@arris.com',
        "first_name": "Cool",
        "id": 568,
        "last_name": "Contractor",
        "rate": 50,
        "currency": "CAD",
        "title": "Keyboard User",
        "direct_report": "",
        "image": "https://ui-avatars.com/api/?name=Cool+Con",
        "approved": false,
        "last_hire_date": '2017-05-30',
        "expected_end_date": '2020-06-30',
        "managers": [
            {
                "username": "fhasle",
                "first_name": "Fred",
                "last_name": "Hasle"
            },
            {
                "username": "jraynor",
                "first_name": "Jack",
                "last_name": "Raynor"
            },
            {
                "username": "ctrivedi",
                "first_name": "Chirag",
                "last_name": "Trivedi"
            },
        ],
        "disposition_change_approval": {},
        "disposition_changes": [],
    },
    {
        'selected': false,
        'visible': true,
        'network_login': 'nguy',
        'email_address': 'neato.guy@arris.com',
        "first_name": "Neato",
        "id": 570,
        "last_name": "Guy",
        "rate": 50,
        "currency": "USD",
        "title": "Whiteboard Cleaner",
        "direct_report": "",
        "image": "https://ui-avatars.com/api/?name=Neato+Con",
        "approved": false,
        "last_hire_date": '2017-07-30',
        "expected_end_date": '2020-10-30',
        "managers": [
            {
                "username": "jraynor",
                "first_name": "Jack",
                "last_name": "Raynor"
            },
            {
                "username": "ctrivedi",
                "first_name": "Chirag",
                "last_name": "Trivedi"
            },
        ],
        "disposition_change_approval": {},
        "disposition_changes": [],
    },
    {
        'selected': false,
        'visible': true,
        'network_login': 'mbash',
        'email_address': 'mark.bash@arris.com',
        "first_name": "Mark",
        "id": 571,
        "last_name": "Bash",
        "rate": 50,
        "currency": "USD",
        "title": "Script Kiddie",
        "direct_report": "",
        "image": "https://ui-avatars.com/api/?name=Neato+Con",
        "approved": false,
        "last_hire_date": '2011-08-30',
        "expected_end_date": '2020-06-30',
        "managers": [
            {
                "username": "mrmanager",
                "first_name": "Mister",
                "last_name": "Manager"
            },
            {
                "username": "ctrivedi",
                "first_name": "Chirag",
                "last_name": "Trivedi"
            },
        ],
        "disposition_change_approval": {},
        "disposition_changes": [],
    },
    {
        'selected': false,
        'visible': true,
        'network_login': 'thejanitor',
        'email_address': 'the.janitor@arris.com',
        "first_name": "Janitor",
        "id": 573,
        "last_name": "The",
        "rate": 50,
        "currency": "USD",
        "title": "Most Important",
        "direct_report": "",
        "image": "https://ui-avatars.com/api/?name=Neato+Con",
        "approved": false,
        "last_hire_date": '2010-06-30',
        "expected_end_date": '2020-06-30',
        "managers": [
            {
                "username": "bmcclelland",
                "first_name": "Bruce",
                "last_name": "McClelland"
            },
        ],
        "disposition_change_approval": {},
        "disposition_changes": [],
    }
];

export const HRPeople = ['hrperson'];

export default function employees(state = initialState, action){
    switch(action.type){
    case ADD_EMPLOYEE:
        return [...state, action.employee]
    case SET_EMPLOYEE:
        return state.map((employee) => {
            if (employee.id === action.employee.id){
                return action.employee; // For now, we need to pass the entire sucker and overwrite
            }
            return employee;
        });
    case ADD_DISPOSITION_CHANGE:
        return state.map((employee) => {
            if (employee.id === action.id){
                return Object.assign({}, employee, {
                    disposition_changes: [action.disposition_change, ...employee.disposition_changes]
                });
            }
            return employee;
        });
    case SET_APPROVAL:
        return state.map((employee) => {
            if (employee.id === action.id){
                let newObj = {...employee};
                newObj.disposition_change_approval[action.manager_username] = action.approval
                return newObj;
            }
            return employee;
        });
    case CLEAR_APPROVALS:
        return state.map((employee) => {
            if (employee.id === action.id){
                return {...employee, disposition_change_approval: {}};
            }
            return employee;
        });
    case FILTER_EMPLOYEES: {
        let hrEnabled = false;
        if (HRPeople.indexOf(action.managerUsername) >= 0){
            hrEnabled = true;
        }
        return state.map((employee) => {
            console.log("Checking", employee.first_name, employee.last_name);
            for (let i = 0; i < employee.managers.length; i++){
                if (hrEnabled || employee.managers[i].username === action.managerUsername){
                    return {...employee, visible: true, selected: false};
                }
            }
            return {...employee, visible: false, selected: false};
        });
    }
    case RESET_EMPLOYEES:
        return initialState;
    case TOGGLE_SELECTED:
        return state.map((employee) => {
            if (employee.id == action.id){
                return {...employee, selected: !employee.selected}
            }
            return employee;
        });
    case TOGGLE_ALL_SELECTED:
        if (action.indeterminate){
            return state.map(employee => {
                if (employee.visible){
                    return {...employee, selected: false};
                }
                return employee;
            });
        }
        return state.map(employee => {
            if (employee.visible){
                return {...employee, selected: !employee.selected}
            }
            return employee;
        });
    case CLEAR_EMPLOYEES:
        return [];
    default:
        return state;
    }
}
