import { SET_LOGGED_IN, SET_LOGGED_IN_USERNAME, SET_ACTIVE_ROUTE } from '../actions/auth.js';

const initialState = {
    loggedIn: false,
    loggedInUsername: "",
    active: ""
};

export default function auth(state = initialState, action){
    switch(action.type){
    case SET_LOGGED_IN:
        return { ...state, loggedIn: action.logged_in };
    case SET_LOGGED_IN_USERNAME:
        return { ...state, loggedInUsername: action.loggedInUsername };
    case SET_ACTIVE_ROUTE:
        return { ...state, active: action.route };
    default:
        return state;
    }
}
