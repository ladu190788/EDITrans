import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Checkbox, Sticky, Popup, Form, Modal, TextArea, Grid, Pagination, Segment, Button, Menu, Sidebar, Icon, Image, Header } from 'semantic-ui-react';
import {CSVLink, CSVDownload} from 'react-csv';
import 'semantic-ui-css/semantic.min.css';
import { store } from '../store.js';
import _ from 'lodash';
import moment from 'moment';
import FusionCharts from 'fusioncharts';
import Charts from 'fusioncharts/fusioncharts.charts';
import ReactFC from 'react-fusioncharts';
Charts(FusionCharts);

const mapRevenueProps = (state) => {
    return {
        employees: state.employees
    }
}

const myDataSource = {
    "chart": {
        "caption": "Actual Revenues Details",
        "subcaption": "Last year",
        "xaxisname": "Month",
        "yaxisname": "Amount (In USD)",
        "numberprefix": "$",
        "theme": "ocean"
    },
    "categories": [
        {
            "category": [
                {
                    "label": "Jan"
                },
                {
                    "label": "Feb"
                },
                {
                    "label": "Mar"
                },
                {
                    "label": "Apr"
                },
                {
                    "label": "May"
                },
                {
                    "label": "Jun"
                },
                {
                    "label": "Jul"
                },
                {
                    "label": "Aug"
                },
                {
                    "label": "Sep"
                },
                {
                    "label": "Oct"
                },
                {
                    "label": "Nov"
                },
                {
                    "label": "Dec"
                }
            ]
        }
    ],
    "dataset": [
        {
            "seriesname": "Limit Value",
            "data": [
                {
                    "value": "16000"
                },
                {
                    "value": "20000"
                },
                {
                    "value": "18000"
                },
                {
                    "value": "19000"
                },
                {
                    "value": "15000"
                },
                {
                    "value": "21000"
                },
                {
                    "value": "16000"
                },
                {
                    "value": "20000"
                },
                {
                    "value": "17000"
                },
                {
                    "value": "25000"
                },
                {
                    "value": "19000"
                },
                {
                    "value": "23000"
                }
            ]
        },
        {
            "seriesname": "Delta Value",
            "renderas": "line",
            "showvalues": "0",
            "data": [
                {
                    "value": "15000"
                },
                {
                    "value": "16000"
                },
                {
                    "value": "17000"
                },
                {
                    "value": "18000"
                },
                {
                    "value": "19000"
                },
                {
                    "value": "19000"
                },
                {
                    "value": "19000"
                },
                {
                    "value": "19000"
                },
                {
                    "value": "20000"
                },
                {
                    "value": "21000"
                },
                {
                    "value": "22000"
                },
                {
                    "value": "23000"
                }
            ]
        },
        {
            "seriesname": "Revenue",
            "renderas": "area",
            "showvalues": "0",
            "data": [
                {
                    "value": "4000"
                },
                {
                    "value": "5000"
                },
                {
                    "value": "3000"
                },
                {
                    "value": "4000"
                },
                {
                    "value": "1000"
                },
                {
                    "value": "7000"
                },
                {
                    "value": "1000"
                },
                {
                    "value": "4000"
                },
                {
                    "value": "1000"
                },
                {
                    "value": "8000"
                },
                {
                    "value": "2000"
                },
                {
                    "value": "7000"
                }
            ]
        }
    ]
};

const chartConfigs = {
  type: 'mscombi2d',
  width: 700,
  height: 400,
  dataFormat: 'json',
  dataSource: myDataSource,
};

export class Revenue extends Component {
    
	constructor(props){
        super(props);    
    }	
    componentWillReceiveProps(newProps){
        
    }
    render(){
        
        return (
            <div>
                <h4> Coming Soon...</h4>
            </div>
        );
    }
}

export default connect(mapRevenueProps)(Revenue);
