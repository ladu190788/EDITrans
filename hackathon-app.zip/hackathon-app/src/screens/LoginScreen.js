import React, { Component } from 'react';
import { connect } from 'react-redux';
import Form from './Form.react';
import '../css/_form.css';
import '../css/_form-page.css';


const mapStateToProps = (state, props) => {
    return {
    };
};

class LoginScreen extends Component {
    render() {
        const dispatch = this.props.dispatch;
        return (
            <div className="">
                <div className="">
                 
                    <Form dispatch={dispatch} history={this.props.history} onSubmit={this._login} btnText={"Login"} />
                </div>
            </div>
        );
    }

    _login(username, password) {
        /*this.props.dispatch(login(username, password));*/
    }
}

export default connect(mapStateToProps, null)(LoginScreen);
