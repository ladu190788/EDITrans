/**
 * Form.react.js
 *
 * The form with a username and a password input field, both of which are
 * controlled via the application state.
 *
 */

import React, { Component } from 'react';
import { Container, Segment, Button, Menu, Sidebar, Icon } from 'semantic-ui-react';
import { store } from '../store.js';
import { setLoggedIn, setLoggedInUsername, setActiveRoute } from '../actions/auth.js';
import userImg from './user.png';
import '../css/_form.css';
import '../css/_form-page.css';

// Object.assign is not yet fully supported in all browsers, so we fallback to
// a polyfill
const assign = Object.assign;

class LoginForm extends Component {
    constructor(props){
        super(props);
        this.state = {
            username: ""
        }
    }

    handleLogin = (props) => {
        
        store.dispatch(setLoggedIn(true))
        store.dispatch(setLoggedInUsername(this.state.username));
        store.dispatch(setActiveRoute('dashboard'));
        props.history.push('/dashboard');
    }

  render() {
    return(
	<div className="form-page__form-wrapper">    
			<div class="container">			  
			  <div class="row" id="pwd-container">
				<div class="col-md-4"></div>				
				<div class="col-md-4">
				  <section class="login-form">
					<form method="post" action="#" role="login" onSubmit={this._onSubmit.bind(this)}>
					  <img src={userImg} alt="user Image"  />
					  <input type="email" name="email" placeholder="Username" required class="form-control input-lg" id="username" onChange={this._changeUsername.bind(this)}/>					  
					  <input type="password" class="form-control input-lg" id="password" placeholder="Password" required=""  onChange={this._changePassword.bind(this)}/>					  
					  <div class="pwstrength_viewport_progress"></div>			  
					  <button type="submit" name="go" class="btn btn-lg btn-primary btn-block" onClick={() => this.handleLogin(this.props)} >Login</button>
					  <div>			   
					  </div>	  
					</form>
				  </section>  
				  </div>
			  </div>
			</div>				
	</div>
    );
  }

    // Change the username in the app state
    _changeUsername(evt) {
        this.setState({username: evt.target.value});
        var newState = this._mergeWithCurrentState({
            username: evt.target.value
        });

        this._emitChange(newState);
    }

  // Change the password in the app state
  _changePassword(evt) {
    var newState = this._mergeWithCurrentState({
      password: evt.target.value
    });

    this._emitChange(newState);
  }

  // Merges the current state with a change
  _mergeWithCurrentState(change) {
    /*return assign(this.props.data, change);*/
  }

  // Emits a change of the form state to the application state
  _emitChange(newState) {
    /*this.props.dispatch(changeForm(newState));*/
  }

  // onSubmit call the passed onSubmit function
  _onSubmit(evt) {
    evt.preventDefault();
    /*this.props.onSubmit(this.props.data.username, this.props.data.password);*/
  }
}

export default LoginForm;
