import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Checkbox, Sticky, Popup, Form, Modal, TextArea, Grid, Pagination, Segment, Button, Menu, Sidebar, Icon, Image, Header } from 'semantic-ui-react';
import {CSVLink, CSVDownload} from 'react-csv';
import 'semantic-ui-css/semantic.min.css';
import { store } from '../store.js';
import _ from 'lodash';
import moment from 'moment';
import FusionCharts from 'fusioncharts';
import Charts from 'fusioncharts/fusioncharts.charts';
import ReactFC from 'react-fusioncharts';
Charts(FusionCharts);

const mapRevenueProps = (state) => {
    return {
        employees: state.employees
    }
}

const myDataSource = {
  chart: {
    caption: 'Resource Allocation Data',
    subCaption: '',
    numberPrefix: '',
  },
  data: [
    {
      label: 'Jan/2017',
      value: '10',
    },
    {
      label: 'Feb/2017',
      value: '30',
    },
    {
      label: 'Mar/2017',
      value: '8',
      value: '8',
    },
    {
      label: 'Apr/2017',
      value: '15',
    },
    {
      label: 'May/2017',
      value: '16',
    },
	{
      label: 'June/2017',
      value: '17',
    },
	{
      label: 'July/2017',
      value: '18',
    },
	{
      label: 'Aug/2017',
      value: '10',
    },
	{
      label: 'Sep/2017',
      value: '11',
    }
  ],
};

const chartConfigs = {
  type: 'column2d',
  width: 600,
  height: 400,
  dataFormat: 'json',
  dataSource: myDataSource,
};

export class Revenue extends Component {
    
	constructor(props){
        super(props);    
    }	
    componentWillReceiveProps(newProps){
        
    }
    render(){
        
        return (
            <div>
               <h4> Coming Soon...</h4>
            </div>
        );
    }
}

export default connect(mapRevenueProps)(Revenue);
