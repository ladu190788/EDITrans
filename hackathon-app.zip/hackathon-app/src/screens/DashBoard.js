import React from 'react';
import { Button, Divider, Form, Grid, Segment } from 'semantic-ui-react'
import '../css/_dashboard-page.css';




class Home extends React.Component {
 
      downloadTxtFile = () => {
    const element = document.createElement("a");
    const file = new Blob([document.getElementById('myInput').value], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = "myFile.txt";
    document.body.appendChild(element); // Required for this to work in FireFox
    element.click();
  }
    render() {
      return (
	 <div >
	   <div class="row header1">
		  <div class="col-sm-12 col-lg-12"> <h1>Real Time Eligibility</h1> </div>  
	   </div>
           <div class="realTimeElg">
		   <div class="row formRow">
			  <div class="col-sm-2 col-lg-2">
				<label class=""><b>Payer Name </b></label>  <font color="red">*</font>
			  </div>
			  <div class="col-sm-3"><input type="text" class="form-control" id="usr" placeholder="Payer Name"></input></div>
			  <div class="col-sm-6 col-lg-6"></div>
			  
		   </div>
	 	   <div class="row formRow2">
			  <div class="col-sm-2 col-lg-2">
			  	<label class="w3-text-blue"><b>Provider NPI <font color="red"> * </font> </b></label>
			  </div>
			  <div class="col-sm-3"><input type="text" class="form-control" id="usr" placeholder="Provider NPI"></input></div>
			  <div class="col-sm-2"></div>
			  <div class="col-sm-2 col-lg-2">
				<label class="w3-text-blue"><b>Provider Name  <font color="red"> * </font> </b></label>
			  </div>
			  <div class="col-sm-3">
				<input type="text" class="form-control" id="usr"  placeholder="Provider Name" ></input>
			  </div>
		   </div>
	   </div>
 	   <div class="row header2">
		  <div class="col-sm-12 col-lg-12"> <h1>Subscriber / Patient</h1> </div>  
	   </div>
	   <div class="realTimeElg">
	   <div class="row formRow">
		  <div class="col-sm-2 col-lg-2">
			<label class="w3-text-blue"><b>Date of Service </b></label>
			 <font color="red"> * </font>
                  </div>
		  <div class="col-sm-3">
		  	<div class='input-group date' id='datetimepicker1'>
			<input type='text' class="form-control" placeholder="DD/MM/YYYY" />
			<span class="input-group-addon">
				<span class="glyphicon glyphicon-calendar"></span>
			</span>
                  </div>
		  </div>
		  <div class="col-sm-2"></div>
		  <div class="col-sm-2 col-lg-2">
			<label class="w3-text-blue"><b>Benefit/Service Type Code  <font color="red"> * </font> </b></label>
		  </div>
		  <div class="col-sm-3">
			<select class="selectStyle">
			  <option value="select">Select</option>
			  <option value="volvo">Medical Care</option>
			  <option value="saab">Surgical</option>
			  <option value="Consultation">Consultation</option>
			  <option value="Diagonistic X-Ray">Diagonistic X-Ray</option>
			  <option value="Diagonistic Lab">Diagonistic Lab</option>
			  <option value="Radiation Therapy">Radiation Therapy</option>
			  <option value="Anesthesia">Anesthesia</option>
			  <option value="Surgical Assistance">Surgical Assistance</option>
                          <option value="Other Medical">Other Medical</option>
                          <option value="Blood Charges">Blood Charges</option>
			</select>
		  </div>
	   </div>
	   <div class="row formRow1">
		  <div class="col-sm-2 col-lg-2">
			<label class="w3-text-blue"><b>Search Option  <font color="red"> * </font> </b></label>
		  </div>
		  <div class="col-sm-10 col-lg-10">
		  	<select class="selectStyle">
			  <option value="select">Select</option>
			  <option value="volvo">Member ID, Last Name, First Name & Patient DOB</option>
			  <option value="saab">Member ID, Last Name, Patient DOB</option>
			  <option value="Consultation">Member ID, First Name & Patient DOB</option>
			  <option value="Diagonistic X-Ray">Member ID, Patient DOB</option>
			  <option value="Diagonistic Lab">Member ID, Last Name, First Name</option>
			  <option value="Radiation Therapy">Last Name, First Name & Patient DOB</option>
			</select>
		  </div>		  
	   </div>
	   <div class="row formRow1">
		  <div class="col-sm-2 col-lg-2">
			<label class="w3-text-blue"><b>Subscriber's / Patient First Name </b></label>
		  </div>
		  <div class="col-sm-3"><input type="text" class="form-control" id="usr" placeholder="Subscriber's / Patient First Name"></input></div>
		  <div class="col-sm-2"></div>
		  <div class="col-sm-2 col-lg-2">
			<label class="w3-text-blue"><b>Subscriber's / Patient Last Name </b></label>
		  </div>
		  <div class="col-sm-3"><input type="text" class="form-control" id="usr" placeholder="Subscriber's / Patient Last Name"></input></div>
	   </div>
	   <div class="row formRow1">
		  <div class="col-sm-2 col-lg-2">
		      <label class="w3-text-blue"><b>Subscriber Member ID </b></label>
		  </div>
		  <div class="col-sm-3"><input type="text" class="form-control" id="usr" placeholder="Subscriber Member ID"></input></div>
		  <div class="col-sm-2"></div>
		  <div class="col-sm-2 col-lg-2">
			<label class="w3-text-blue"><b>Subscriber / Patient DOB </b></label>
		  </div>
		  <div class="col-sm-3">
		       <div class='input-group date' id='datetimepicker2'>
			<input type='text' class="form-control" placeholder="DD/MM/YYYY" />
			<span class="input-group-addon">
				<span class="glyphicon glyphicon-calendar"></span>
			</span></div>
		  </div>
	   </div>
          
	   <div class="row formRow3">
		  <div class="col-sm-3 col-lg-3"></div>
		  <div class="col-sm-2"><button type="button" class="btn btn-primary formButton">Validate Data</button></div>
		  <div class="col-sm-2"><a href="output.txt" download="output.txt"><button type="button" class="btn btn-primary formButton">Create EDI Data</button></a></div>
		  <div class="col-sm-2"><button type="button" class="btn btn-primary formButton">Process EDI Data</button></div>
		  <div class="col-sm-3 col-lg-3"></div>
	   </div>
	</div>
	</div>
      );
   }
}
export default Home;
