# Contractor Conversion Management Tool Frontend

## Getting Started
1. Install node modules

        :::bash
        npm i

2. Start dev server

        :::bash
        npm start

## Structure
We assume that data coming from PSA would look similar to this:

        :::json
        {
            "logged_in_username": 'mrmanager',
            'employees': [
                {
                    'first_name': 'Zhan',
                    'last_name': 'Liau',
                    'title': 'SO Results Aggregator',
                    'salary': -1,
                    'id': 123
                },
                {
                    'first_name': 'Bernard',
                    'last_name': 'Bois',
                    'title': 'Demo(litions) Expert'
                    'salary': -1
                    'id': 234
                }
            ]
        }

We also assume that the API provides easily resolvable links to other information stemming from the employee tree
With this in mind, we can structure the state tree like this:

        :::json
        {
            'auth': {
                'logged_in': true,
                'logged_in_username': 'mrmanager',
                'token': 'abcdef12345'
            },
            'employees': [ ... ]
        }

