---
name: "⚡Angular Framework"
about: Issues and feature requests for Angular Framework

---

🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑

Please file any Angular Framework issues at: https://github.com/angular/angular/issues/new/choose

For the time being, we keep Angular issues in a separate repository.

🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑🛑
