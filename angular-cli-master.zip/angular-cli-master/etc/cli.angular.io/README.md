
# Angular CLI microsite

This folder contains all the static files used for the Angular CLI microsite
(http://cli.angular.io).

To make changes on the frontend, just update the files here, and ask the
caretaker to deploy the new site when the commit is merged. Your commit should
be of scope `docs:` (**NOT** `fix` or `feat`).

## Deploy

To deploy, use your firebase credentials to login, then use `firebase deploy`
from this folder. There is currently no build step.
