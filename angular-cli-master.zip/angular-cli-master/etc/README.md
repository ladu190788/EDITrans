# `/etc` Folder

This folder is for files that doesn't fit in other directories in the root folder.
