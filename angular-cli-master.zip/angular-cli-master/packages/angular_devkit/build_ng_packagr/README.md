# Angular Build Architect for ng-packagr

WIP